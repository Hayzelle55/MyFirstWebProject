<?php
//Login
session_start();
$valid_email = "email";
$valid_password = "pass";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    if ($email == $valid_email && $password == $valid_password) {
        $_SESSION['email'] = $email;
        echo "Login successful! Welcome, " . $_SESSION['email'] . ".";
    } else {
        echo "Invalid email or password.";
    }
}
?>



//Contact

$name = $_POST['name'];
$email = $_POST['email'];
$message = $_POST['message'];

$to = 'estherpaulokon2006@gmail.com';
$subject = 'Contact form Submission';
$body = "Name: $name\nEmail;
$email\nMessage: $message";

$headers = 'From: ' . $email . "\r\n" .
           'Reply-To: ' . $email . "\r\n" .
           'X-Mailer: PHP/' .phpversion();
mail($to, $subject, $body, $headers);
echo 'Thank you for contacting us!';
?>

//Price

$productName = $_POST['$product_Name'];
$stmt = $pdo->prepare('SELECT price FROM products WHERE name = ?');
$tmt->execute([$$productName]);
$price = $stmt->fetchColumn();

if ($price) {
    echo 'The price of ${$productName} is $${price}.';
} else {
    echo 'Product not found.';
}
?>