//Login
const loginBtn = document.getElementsById('login');
const signinContainer = document.getElementsById('sign-in');

loginBtn.addEventListener('click',() =>{loginContainer.style.display = 'block';
loginBtn.addEventListener('click',() =>{signinContainer.classList.toggle('container');});
if (signinContainer.classList.contains('container'))
{
    signinForm.element[0].focus();
}
signinForm.addEventListener('submit',(e)=> {e.preventDefault();});


// Ask for price
document.addEventListener("DOMContentLoaded", function() {
    const askPriceBtn = document.getElementById("askPriceBtn");
    const priceContainer = document.getElementById("priceContainer");
    askPriceBtn.addEventListener("click", function() {
        const price = "$10";
        priceContainer.innerText = "The price is: " + price;
    });
});


//Contact
const form = document.getElementsById("contact-form");
const submitBtn = document.getElementsById("submit-btn");
form.addEventListener('submit', (e) => { e.preventDefault();
    const name = document.getElementsById("name").value;
    const email = document.getElementsById("email").value;
    const message = document.getElementsById("message").value;
    const xhr = new XMLHttpRequest();
    xhr.open('POST' 'contact.php', true);
    xhr.setRequestheader('Content-type','application/x-www-form-urlencoded');
    xhr.onload = function() {
        if (xhr.status == 200){
            console.log(xhr.responseText);
            form.reset();
        }
    };
    xhr.send('name=${name}&email=${email}&message=${message}');
});
